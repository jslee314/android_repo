App that fetches Rick and Morty Characters. This repository aims at explaining how to use Sealed Classes to Manage State
