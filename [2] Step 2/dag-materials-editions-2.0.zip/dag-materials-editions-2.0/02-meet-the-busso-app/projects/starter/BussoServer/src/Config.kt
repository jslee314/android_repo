package com.raywenderlich.busso.server

// The version for the Busso APIs
const val API_VERSION = "/api/v1"